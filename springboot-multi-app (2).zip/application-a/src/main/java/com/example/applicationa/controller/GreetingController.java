package com.example.applicationa.controller;

import com.example.apimodels.model.GreetingRequest;
import com.example.apimodels.model.GreetingResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class GreetingController {

    @PostMapping("/hello")
    public ResponseEntity<GreetingResponse> greet(@Valid @RequestBody GreetingRequest request) {
        GreetingResponse response = new GreetingResponse();
        response.setMessage("Hello, " + request.getName() + "!");
        return ResponseEntity.ok(response);
    }
}
