package com.example.applicationb.controller;

import com.example.apimodels.model.GreetingRequest;
import com.example.apimodels.model.GreetingResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/client")
public class ClientController {

    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("/greet")
    public ResponseEntity<GreetingResponse> callGreeting(@RequestBody GreetingRequest request) {
        String url = "http://localhost:8081/api/hello";
        return restTemplate.postForEntity(url, request, GreetingResponse.class);
    }
}
